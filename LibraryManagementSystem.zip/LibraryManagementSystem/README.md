# Library Management System (Core Java + JDBC)

A terminal-based Library Management System written in plain Java (JDK 11+). It manages a
book catalogue, library members, and the full issue/return cycle, storing everything in a
relational database through JDBC so all data survives between program runs.

---

## Features Implemented

**Books**
- Add, update, delete and search books (title, author, ISBN, category, copies).
- Search by partial title / author / category or exact ISBN.
- List books sorted by title (`Comparable`) or by copies available (`Comparator`).
- Duplicate ISBNs are rejected; a book that is currently on loan cannot be deleted.

**Members**
- Register, update, delete and search members.
- Two membership types with different borrow limits: STANDARD (3 books), PREMIUM (10).
- Duplicate e-mails are rejected; a member holding books cannot be deleted.

**Issue / Return**
- Issue a book to a member with an automatic 14-day due date.
- Issuing is blocked when available copies reach 0 or the member hit their borrow limit.
- Returning restores the copy count and reports overdue days.
- Full borrowing history per member.

**Reports**
- Currently borrowed books.
- Overdue books, sorted by how late they are, with total outstanding fines.
- Copies per category (`TreeMap`, alphabetical) and titles per author (`HashMap`).
- Times-borrowed ranking per title.

**Stretch goals included:** fine calculation for overdue returns (Rs. 5 per day), and
category-wise / author-wise statistics reports.

---

## Assignment Requirements Mapping

| Requirement | Where it is implemented |
|---|---|
| Abstract class | `model/Person.java` (abstract `getRole()`, `getBorrowLimit()`) |
| Inheritance (2+ subtypes) | `model/Member.java`, `model/Librarian.java` |
| Polymorphism | Overridden `getRole()`, `getBorrowLimit()`, `toString()`; overloaded `Member` / `Book` constructors |
| Encapsulation | All model fields private with getters/setters |
| Interface use | `Book implements Comparable<Book>` |
| 5+ classes beyond Main | 5 models, 4 DAO, 1 service, 2 util, 3 exceptions |
| `List` | `ArrayList<Book>`, `ArrayList<Member>`, `ArrayList<Loan>` in the DAOs and service |
| `Map` | `BookDAO.findAllAsMap()` (id → Book `HashMap`), `TreeMap` category report, `HashMap` author report |
| Sorting / filtering / iteration | `Comparator` sorts in `LibraryService`, overdue filtering, stream sort in the report |
| JDBC connection | `dao/DatabaseConnection.java` |
| Full CRUD via DB | `BookDAO`, `MemberDAO`, `LoanDAO` |
| `PreparedStatement` everywhere | every query in the DAO classes |
| try-with-resources | every `Connection` / `PreparedStatement` / `ResultSet` block |
| `SQLException` handled meaningfully | caught per menu action in `Main` with a clear message |
| Custom exceptions | `RecordNotFoundException`, `DuplicateRecordException`, `BookUnavailableException` |
| Menu-driven UI + validation | `main/Main.java` + `util/InputHelper.java` |
| No hard-coded credentials | `util/ConfigLoader.java` reads `config/db.properties` (git-ignored) or env vars |
| Persistence | all state lives in the database, not in memory |

---

## Technologies Used

- Java (JDK 11+; developed and tested on JDK 21)
- JDBC (`java.sql`)
- SQLite via `sqlite-jdbc` 3.46 (default) — MySQL 8 also supported by editing the config
- No frameworks, no build tool required (plain `javac` / `java`)

---

## Project Structure

```
LibraryManagementSystem/
├── src/com/library/
│   ├── main/Main.java                 menu-driven console UI
│   ├── model/    Person, Member, Librarian, Book, Loan
│   ├── dao/      DatabaseConnection, BookDAO, MemberDAO, LoanDAO
│   ├── service/  LibraryService            business rules + collections work
│   ├── util/     InputHelper, ConfigLoader
│   └── exception/ RecordNotFoundException, DuplicateRecordException,
│                  BookUnavailableException
├── config/db.properties.example        copy to db.properties (git-ignored)
├── schema.sql                          MySQL schema + sample data
├── run.sh / run.bat                    compile & run helpers
└── README.md
```

---

## Database Setup

### Option A — SQLite (no server needed, recommended)

1. Download the driver into `lib/`:
   ```bash
   mkdir -p lib
   curl -L -o lib/sqlite-jdbc.jar \
     https://repo1.maven.org/maven2/org/xerial/sqlite-jdbc/3.46.1.3/sqlite-jdbc-3.46.1.3.jar
   ```
2. Create your config:
   ```bash
   cp config/db.properties.example config/db.properties
   ```
   ```properties
   db.url=jdbc:sqlite:library.db
   db.user=
   db.password=
   ```
3. That's it — the app creates the three tables automatically on first start.

### Option B — MySQL

1. Put `mysql-connector-j-8.x.x.jar` in `lib/`.
2. Run the schema:
   ```bash
   mysql -u root -p < schema.sql
   ```
3. In `config/db.properties`:
   ```properties
   db.url=jdbc:mysql://localhost:3306/library_db
   db.user=root
   db.password=your_password
   ```

Instead of the properties file you may export `DB_URL`, `DB_USER`, `DB_PASSWORD`
as environment variables. `config/db.properties` is listed in `.gitignore`, so no
credentials are ever committed.

### Schema

```sql
CREATE TABLE books (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    title            VARCHAR(150) NOT NULL,
    author           VARCHAR(100) NOT NULL,
    isbn             VARCHAR(20)  NOT NULL UNIQUE,
    category         VARCHAR(50)  NOT NULL,
    total_copies     INT          NOT NULL,
    available_copies INT          NOT NULL
);

CREATE TABLE members (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    email           VARCHAR(120) NOT NULL UNIQUE,
    phone           VARCHAR(25)  NOT NULL,
    membership_type VARCHAR(10)  NOT NULL,
    join_date       DATE         NOT NULL
);

CREATE TABLE loans (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    book_id     INT  NOT NULL,
    member_id   INT  NOT NULL,
    issue_date  DATE NOT NULL,
    due_date    DATE NOT NULL,
    return_date DATE NULL,
    fine        DOUBLE DEFAULT 0,
    FOREIGN KEY (book_id)   REFERENCES books(id),
    FOREIGN KEY (member_id) REFERENCES members(id)
);
```

The full script, including optional sample rows, is in `schema.sql`.

---

## How to Compile and Run

Linux / macOS:

```bash
chmod +x run.sh
./run.sh
```

Windows:

```bat
run.bat
```

Manually:

```bash
mkdir -p out
javac -d out $(find src -name "*.java")
java -cp "out:lib/sqlite-jdbc.jar" com.library.main.Main     # Windows: use ; instead of :
```

---

## Sample Session

```
==============================================================
        LIBRARY MANAGEMENT SYSTEM  (core Java + JDBC)
  Signed in as Desk Staff (LIBRARIAN), borrow limit 20
==============================================================

---------------- MAIN MENU ----------------
 BOOKS    1) Add   2) List   3) Search   4) Update   5) Delete
 MEMBERS  6) Add   7) List   8) Search   9) Update  10) Delete
 CIRCUL. 11) Issue book  12) Return book  13) Member history
 REPORTS 14) Borrowed & overdue   15) Category/author stats
          0) Exit
Choose an option: 2

ID     TITLE                            AUTHOR               ISBN            CATEGORY     AVAIL/TOTAL
-----------------------------------------------------------------------------------------------
#1    Head First Java                  Kathy Sierra         9780596009205   Programming  2/3
Total: 1 title(s).

Choose an option: 11
Book id: 1
Member id: 1

Issued 'Head First Java' to Popeye Sharma. Due on 2026-10-05 (14 days).

Choose an option: 11
Book id: 1
Member id: 1

Cannot issue: 'Head First Java' has 0 copies available right now.

Choose an option: 14
== CURRENTLY BORROWED (1) ==
#1    Head First Java   Popeye Sharma   issued 2026-09-21 due 2026-10-05  BORROWED  overdue:0d fine:Rs.0.00

== OVERDUE (0) ==
No overdue items.

Choose an option: 15
== COPIES PER CATEGORY (TreeMap, sorted) ==
  Programming          3 copies

== TITLES PER AUTHOR (HashMap) ==
  Kathy Sierra              1 title(s)
```

> **Screenshots:** replace this section with 2–3 real terminal screenshots
> (`docs/screenshot1.png`, etc.) taken on your own machine, as Section 3.3 requires.

---

## Known Limitations

- Single-user console application; no concurrent access handling.
- Fines are calculated and displayed, but there is no payment/settlement record.
- No reservation/waitlist queue for unavailable books (listed stretch goal, not attempted).
- No login/authentication: the librarian identity shown at startup is fixed.
- Reports print to the terminal only; there is no CSV/PDF export.

---

## Suggested Git Commit History (8–10 commits)

1. `Initial project structure and .gitignore`
2. `Add Person abstract class with Member and Librarian subtypes`
3. `Add Book and Loan model classes`
4. `Add JDBC connection helper and config loader`
5. `Implement BookDAO with full CRUD using PreparedStatement`
6. `Implement MemberDAO with search and duplicate-email check`
7. `Implement LoanDAO for issue/return tracking`
8. `Add LibraryService business rules with collections and sorting`
9. `Add custom exceptions and input validation helper`
10. `Add menu-driven Main, schema.sql and README`
