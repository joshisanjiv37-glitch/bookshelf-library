@echo off
REM Compile and run the Library Management System (Windows).
if not exist out mkdir out
dir /s /b src\*.java > sources.txt
javac -d out @sources.txt
del sources.txt
for %%f in (lib\*.jar) do set DRIVER=%%f
java -cp "out;%DRIVER%" com.library.main.Main
pause
