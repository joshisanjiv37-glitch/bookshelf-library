#!/usr/bin/env bash
# Compile and run the Library Management System (Linux/macOS).
set -e

DRIVER=$(ls lib/*.jar 2>/dev/null | head -n 1)
if [ -z "$DRIVER" ]; then
  echo "No JDBC driver found in lib/. Download one, e.g.:"
  echo "  curl -L -o lib/sqlite-jdbc.jar https://repo1.maven.org/maven2/org/xerial/sqlite-jdbc/3.46.1.3/sqlite-jdbc-3.46.1.3.jar"
  exit 1
fi

mkdir -p out
javac -d out $(find src -name "*.java")
java -cp "out:$DRIVER" com.library.main.Main
