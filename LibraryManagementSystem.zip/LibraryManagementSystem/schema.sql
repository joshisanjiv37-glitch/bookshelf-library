-- Library Management System - database schema
-- MySQL version. For SQLite, drop the CREATE DATABASE/USE lines and
-- replace "INT AUTO_INCREMENT PRIMARY KEY" with "INTEGER PRIMARY KEY AUTOINCREMENT".

CREATE DATABASE IF NOT EXISTS library_db;
USE library_db;

CREATE TABLE IF NOT EXISTS books (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    title            VARCHAR(150) NOT NULL,
    author           VARCHAR(100) NOT NULL,
    isbn             VARCHAR(20)  NOT NULL UNIQUE,
    category         VARCHAR(50)  NOT NULL,
    total_copies     INT          NOT NULL,
    available_copies INT          NOT NULL
);

CREATE TABLE IF NOT EXISTS members (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    email           VARCHAR(120) NOT NULL UNIQUE,
    phone           VARCHAR(25)  NOT NULL,
    membership_type VARCHAR(10)  NOT NULL,
    join_date       DATE         NOT NULL
);

CREATE TABLE IF NOT EXISTS loans (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    book_id     INT  NOT NULL,
    member_id   INT  NOT NULL,
    issue_date  DATE NOT NULL,
    due_date    DATE NOT NULL,
    return_date DATE NULL,
    fine        DOUBLE DEFAULT 0,
    FOREIGN KEY (book_id)   REFERENCES books(id),
    FOREIGN KEY (member_id) REFERENCES members(id)
);

-- Optional sample data for testing
INSERT INTO books (title, author, isbn, category, total_copies, available_copies) VALUES
('Head First Java',          'Kathy Sierra',   '9780596009205', 'Programming', 4, 4),
('Clean Code',               'Robert Martin',  '9780132350884', 'Programming', 2, 2),
('Muna Madan',               'Laxmi Devkota',  '9789937000011', 'Poetry',      5, 5),
('Introduction to Algorithms','Thomas Cormen', '9780262033848', 'Computing',   3, 3);

INSERT INTO members (name, email, phone, membership_type, join_date) VALUES
('Popeye Sharma', 'popeye@example.com', '9801111111', 'PREMIUM',  '2026-01-10'),
('Sita Karki',    'sita@example.com',   '9802222222', 'STANDARD', '2026-02-05');
