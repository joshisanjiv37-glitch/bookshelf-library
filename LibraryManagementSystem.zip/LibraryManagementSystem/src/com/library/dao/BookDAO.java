package com.library.dao;

import com.library.exception.DuplicateRecordException;
import com.library.exception.RecordNotFoundException;
import com.library.model.Book;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** All SQL for the books table. Every query uses PreparedStatement. */
public class BookDAO {

    public void insert(Book book) throws SQLException, DuplicateRecordException {
        if (findByIsbn(book.getIsbn()) != null) {
            throw new DuplicateRecordException("A book with ISBN " + book.getIsbn()
                    + " already exists.");
        }
        String sql = "INSERT INTO books (title, author, isbn, category, total_copies, "
                + "available_copies) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, book.getTitle());
            ps.setString(2, book.getAuthor());
            ps.setString(3, book.getIsbn());
            ps.setString(4, book.getCategory());
            ps.setInt(5, book.getTotalCopies());
            ps.setInt(6, book.getAvailableCopies());
            ps.executeUpdate();
        }
    }

    public List<Book> findAll() throws SQLException {
        String sql = "SELECT * FROM books ORDER BY id";
        List<Book> books = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                books.add(map(rs));
            }
        }
        return books;
    }

    /** HashMap cache: book id -> Book, for O(1) lookups in reports. */
    public Map<Integer, Book> findAllAsMap() throws SQLException {
        Map<Integer, Book> index = new HashMap<>();
        for (Book book : findAll()) {
            index.put(book.getId(), book);
        }
        return index;
    }

    public Book findById(int id) throws SQLException, RecordNotFoundException {
        String sql = "SELECT * FROM books WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return map(rs);
                }
            }
        }
        throw new RecordNotFoundException("No book found with id " + id + ".");
    }

    public Book findByIsbn(String isbn) throws SQLException {
        String sql = "SELECT * FROM books WHERE isbn = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, isbn);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    /** Search by title, author or category (partial, case-insensitive). */
    public List<Book> search(String keyword) throws SQLException {
        String sql = "SELECT * FROM books WHERE LOWER(title) LIKE ? "
                + "OR LOWER(author) LIKE ? OR LOWER(category) LIKE ? OR isbn = ?";
        List<Book> results = new ArrayList<>();
        String like = "%" + keyword.toLowerCase() + "%";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, like);
            ps.setString(2, like);
            ps.setString(3, like);
            ps.setString(4, keyword);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    results.add(map(rs));
                }
            }
        }
        return results;
    }

    public void update(Book book) throws SQLException, RecordNotFoundException {
        String sql = "UPDATE books SET title = ?, author = ?, isbn = ?, category = ?, "
                + "total_copies = ?, available_copies = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, book.getTitle());
            ps.setString(2, book.getAuthor());
            ps.setString(3, book.getIsbn());
            ps.setString(4, book.getCategory());
            ps.setInt(5, book.getTotalCopies());
            ps.setInt(6, book.getAvailableCopies());
            ps.setInt(7, book.getId());
            if (ps.executeUpdate() == 0) {
                throw new RecordNotFoundException("No book found with id " + book.getId() + ".");
            }
        }
    }

    public void delete(int id) throws SQLException, RecordNotFoundException {
        String sql = "DELETE FROM books WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            if (ps.executeUpdate() == 0) {
                throw new RecordNotFoundException("No book found with id " + id + ".");
            }
        }
    }

    /** Used when issuing (delta = -1) and returning (delta = +1) a copy. */
    public void changeAvailableCopies(int bookId, int delta) throws SQLException {
        String sql = "UPDATE books SET available_copies = available_copies + ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, delta);
            ps.setInt(2, bookId);
            ps.executeUpdate();
        }
    }

    private Book map(ResultSet rs) throws SQLException {
        return new Book(
                rs.getInt("id"),
                rs.getString("title"),
                rs.getString("author"),
                rs.getString("isbn"),
                rs.getString("category"),
                rs.getInt("total_copies"),
                rs.getInt("available_copies"));
    }
}
