package com.library.dao;

import com.library.util.ConfigLoader;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Single place that opens JDBC connections. Works with SQLite out of the box
 * and with MySQL/PostgreSQL by changing config/db.properties only.
 */
public final class DatabaseConnection {

    private static final String URL =
            ConfigLoader.get("db.url", "DB_URL", "jdbc:sqlite:library.db");
    private static final String USER =
            ConfigLoader.get("db.user", "DB_USER", "");
    private static final String PASSWORD =
            ConfigLoader.get("db.password", "DB_PASSWORD", "");

    private DatabaseConnection() {
    }

    public static Connection getConnection() throws SQLException {
        Connection connection = (USER == null || USER.isEmpty())
                ? DriverManager.getConnection(URL)
                : DriverManager.getConnection(URL, USER, PASSWORD);
        if (URL.startsWith("jdbc:sqlite")) {
            try (Statement st = connection.createStatement()) {
                st.execute("PRAGMA foreign_keys = ON");
            }
        }
        return connection;
    }

    /** Creates the tables on first run so a fresh clone works immediately. */
    public static void initSchema() throws SQLException {
        String autoIncrement = URL.startsWith("jdbc:sqlite")
                ? "INTEGER PRIMARY KEY AUTOINCREMENT"
                : "INT AUTO_INCREMENT PRIMARY KEY";

        String books = "CREATE TABLE IF NOT EXISTS books ("
                + "id " + autoIncrement + ", "
                + "title VARCHAR(150) NOT NULL, "
                + "author VARCHAR(100) NOT NULL, "
                + "isbn VARCHAR(20) NOT NULL UNIQUE, "
                + "category VARCHAR(50) NOT NULL, "
                + "total_copies INT NOT NULL, "
                + "available_copies INT NOT NULL)";

        String members = "CREATE TABLE IF NOT EXISTS members ("
                + "id " + autoIncrement + ", "
                + "name VARCHAR(100) NOT NULL, "
                + "email VARCHAR(120) NOT NULL UNIQUE, "
                + "phone VARCHAR(25) NOT NULL, "
                + "membership_type VARCHAR(10) NOT NULL, "
                + "join_date DATE NOT NULL)";

        String loans = "CREATE TABLE IF NOT EXISTS loans ("
                + "id " + autoIncrement + ", "
                + "book_id INT NOT NULL, "
                + "member_id INT NOT NULL, "
                + "issue_date DATE NOT NULL, "
                + "due_date DATE NOT NULL, "
                + "return_date DATE, "
                + "fine DOUBLE DEFAULT 0, "
                + "FOREIGN KEY (book_id) REFERENCES books(id), "
                + "FOREIGN KEY (member_id) REFERENCES members(id))";

        try (Connection conn = getConnection(); Statement st = conn.createStatement()) {
            st.execute(books);
            st.execute(members);
            st.execute(loans);
        }
    }
}
