package com.library.dao;

import com.library.exception.RecordNotFoundException;
import com.library.model.Loan;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/** All SQL for the loans table, including JOIN queries used by reports. */
public class LoanDAO {

    private static final String SELECT_WITH_NAMES =
            "SELECT l.*, b.title AS book_title, m.name AS member_name "
            + "FROM loans l JOIN books b ON b.id = l.book_id "
            + "JOIN members m ON m.id = l.member_id ";

    public void insert(Loan loan) throws SQLException {
        String sql = "INSERT INTO loans (book_id, member_id, issue_date, due_date, "
                + "return_date, fine) VALUES (?, ?, ?, ?, NULL, 0)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, loan.getBookId());
            ps.setInt(2, loan.getMemberId());
            ps.setDate(3, Date.valueOf(loan.getIssueDate()));
            ps.setDate(4, Date.valueOf(loan.getDueDate()));
            ps.executeUpdate();
        }
    }

    public List<Loan> findAll() throws SQLException {
        return query(SELECT_WITH_NAMES + "ORDER BY l.id");
    }

    public List<Loan> findActive() throws SQLException {
        return query(SELECT_WITH_NAMES + "WHERE l.return_date IS NULL ORDER BY l.due_date");
    }

    public List<Loan> findByMember(int memberId) throws SQLException {
        String sql = SELECT_WITH_NAMES + "WHERE l.member_id = ? ORDER BY l.issue_date DESC";
        List<Loan> loans = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, memberId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    loans.add(map(rs));
                }
            }
        }
        return loans;
    }

    public int countActiveByMember(int memberId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM loans WHERE member_id = ? AND return_date IS NULL";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, memberId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    public Loan findActiveLoan(int bookId, int memberId)
            throws SQLException, RecordNotFoundException {
        String sql = SELECT_WITH_NAMES
                + "WHERE l.book_id = ? AND l.member_id = ? AND l.return_date IS NULL";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, bookId);
            ps.setInt(2, memberId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return map(rs);
                }
            }
        }
        throw new RecordNotFoundException("Member " + memberId
                + " has no open loan for book " + bookId + ".");
    }

    public void markReturned(Loan loan) throws SQLException {
        String sql = "UPDATE loans SET return_date = ?, fine = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(loan.getReturnDate()));
            ps.setDouble(2, loan.getFine());
            ps.setInt(3, loan.getId());
            ps.executeUpdate();
        }
    }

    private List<Loan> query(String sql) throws SQLException {
        List<Loan> loans = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                loans.add(map(rs));
            }
        }
        return loans;
    }

    private Loan map(ResultSet rs) throws SQLException {
        Date returned = rs.getDate("return_date");
        Loan loan = new Loan(
                rs.getInt("id"),
                rs.getInt("book_id"),
                rs.getInt("member_id"),
                rs.getDate("issue_date").toLocalDate(),
                rs.getDate("due_date").toLocalDate(),
                returned == null ? null : returned.toLocalDate());
        loan.setBookTitle(rs.getString("book_title"));
        loan.setMemberName(rs.getString("member_name"));
        return loan;
    }
}
