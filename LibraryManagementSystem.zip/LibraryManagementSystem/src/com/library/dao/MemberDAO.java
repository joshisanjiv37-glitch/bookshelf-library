package com.library.dao;

import com.library.exception.DuplicateRecordException;
import com.library.exception.RecordNotFoundException;
import com.library.model.Member;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/** All SQL for the members table. */
public class MemberDAO {

    public void insert(Member member) throws SQLException, DuplicateRecordException {
        if (findByEmail(member.getEmail()) != null) {
            throw new DuplicateRecordException("A member with email "
                    + member.getEmail() + " is already registered.");
        }
        String sql = "INSERT INTO members (name, email, phone, membership_type, join_date) "
                + "VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, member.getName());
            ps.setString(2, member.getEmail());
            ps.setString(3, member.getPhone());
            ps.setString(4, member.getMembershipType());
            ps.setDate(5, Date.valueOf(member.getJoinDate()));
            ps.executeUpdate();
        }
    }

    public List<Member> findAll() throws SQLException {
        String sql = "SELECT * FROM members ORDER BY id";
        List<Member> members = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                members.add(map(rs));
            }
        }
        return members;
    }

    public Member findById(int id) throws SQLException, RecordNotFoundException {
        String sql = "SELECT * FROM members WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return map(rs);
                }
            }
        }
        throw new RecordNotFoundException("No member found with id " + id + ".");
    }

    public Member findByEmail(String email) throws SQLException {
        String sql = "SELECT * FROM members WHERE email = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    public List<Member> search(String keyword) throws SQLException {
        String sql = "SELECT * FROM members WHERE LOWER(name) LIKE ? OR LOWER(email) LIKE ?";
        List<Member> results = new ArrayList<>();
        String like = "%" + keyword.toLowerCase() + "%";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, like);
            ps.setString(2, like);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    results.add(map(rs));
                }
            }
        }
        return results;
    }

    public void update(Member member) throws SQLException, RecordNotFoundException {
        String sql = "UPDATE members SET name = ?, email = ?, phone = ?, "
                + "membership_type = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, member.getName());
            ps.setString(2, member.getEmail());
            ps.setString(3, member.getPhone());
            ps.setString(4, member.getMembershipType());
            ps.setInt(5, member.getId());
            if (ps.executeUpdate() == 0) {
                throw new RecordNotFoundException("No member found with id "
                        + member.getId() + ".");
            }
        }
    }

    public void delete(int id) throws SQLException, RecordNotFoundException {
        String sql = "DELETE FROM members WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            if (ps.executeUpdate() == 0) {
                throw new RecordNotFoundException("No member found with id " + id + ".");
            }
        }
    }

    private Member map(ResultSet rs) throws SQLException {
        return new Member(
                rs.getInt("id"),
                rs.getString("name"),
                rs.getString("email"),
                rs.getString("phone"),
                rs.getString("membership_type"),
                rs.getDate("join_date").toLocalDate());
    }
}
