package com.library.exception;

/** Thrown when a book has zero available copies or a member hit their limit. */
public class BookUnavailableException extends Exception {

    public BookUnavailableException(String message) {
        super(message);
    }
}
