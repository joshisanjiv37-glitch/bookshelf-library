package com.library.exception;

/** Thrown when an ISBN or member email already exists in the database. */
public class DuplicateRecordException extends Exception {

    public DuplicateRecordException(String message) {
        super(message);
    }
}
