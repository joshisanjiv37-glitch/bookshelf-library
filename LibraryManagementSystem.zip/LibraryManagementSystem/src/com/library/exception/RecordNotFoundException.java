package com.library.exception;

/** Custom checked exception thrown when a book/member/loan id does not exist. */
public class RecordNotFoundException extends Exception {

    public RecordNotFoundException(String message) {
        super(message);
    }
}
