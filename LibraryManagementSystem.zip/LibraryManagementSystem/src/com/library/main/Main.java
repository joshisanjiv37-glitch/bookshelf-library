package com.library.main;

import com.library.dao.DatabaseConnection;
import com.library.exception.BookUnavailableException;
import com.library.exception.DuplicateRecordException;
import com.library.exception.RecordNotFoundException;
import com.library.model.Book;
import com.library.model.Librarian;
import com.library.model.Loan;
import com.library.model.Member;
import com.library.model.Person;
import com.library.service.LibraryService;
import com.library.util.InputHelper;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/** Menu-driven console entry point for the Library Management System. */
public class Main {

    private static final LibraryService service = new LibraryService();
    private static InputHelper input;

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            input = new InputHelper(scanner);

            try {
                DatabaseConnection.initSchema();
            } catch (SQLException e) {
                System.out.println("Could not prepare the database: " + e.getMessage());
                System.out.println("Check config/db.properties and that the server is running.");
                return;
            }

            Person staff = new Librarian(1, "Desk Staff", "desk@library.np",
                    "9800000000", "LIB-001");
            System.out.println("=".repeat(62));
            System.out.println("        LIBRARY MANAGEMENT SYSTEM  (core Java + JDBC)");
            System.out.printf("  Signed in as %s (%s), borrow limit %d%n",
                    staff.getName(), staff.getRole(), staff.getBorrowLimit());
            System.out.println("=".repeat(62));

            boolean running = true;
            while (running) {
                printMenu();
                int choice = input.readIntInRange("Choose an option: ", 0, 15);
                System.out.println();
                switch (choice) {
                    case 1 -> addBook();
                    case 2 -> listBooks();
                    case 3 -> searchBooks();
                    case 4 -> updateBook();
                    case 5 -> deleteBook();
                    case 6 -> registerMember();
                    case 7 -> listMembers();
                    case 8 -> searchMembers();
                    case 9 -> updateMember();
                    case 10 -> deleteMember();
                    case 11 -> issueBook();
                    case 12 -> returnBook();
                    case 13 -> memberHistory();
                    case 14 -> borrowedAndOverdueReport();
                    case 15 -> statisticsReport();
                    case 0 -> running = false;
                    default -> System.out.println("Unknown option.");
                }
                if (running) {
                    input.pause();
                }
            }
            System.out.println("\nGoodbye. All data is saved in the database.");
        }
    }

    private static void printMenu() {
        System.out.println("\n---------------- MAIN MENU ----------------");
        System.out.println(" BOOKS    1) Add   2) List   3) Search   4) Update   5) Delete");
        System.out.println(" MEMBERS  6) Add   7) List   8) Search   9) Update  10) Delete");
        System.out.println(" CIRCUL. 11) Issue book  12) Return book  13) Member history");
        System.out.println(" REPORTS 14) Borrowed & overdue   15) Category/author stats");
        System.out.println("          0) Exit");
    }

    /* ---------------- books ---------------- */

    private static void addBook() {
        try {
            String title = input.readText("Title: ");
            String author = input.readText("Author: ");
            String isbn = input.readText("ISBN: ");
            String category = input.readText("Category: ");
            int copies = input.readIntInRange("Total copies: ", 1, 1000);
            service.addBook(new Book(title, author, isbn, category, copies));
            System.out.println("\nBook added successfully.");
        } catch (DuplicateRecordException e) {
            System.out.println("\nCould not add the book: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("\nDatabase error while adding the book: " + e.getMessage());
        }
    }

    private static void listBooks() {
        try {
            System.out.println("Sort by:  1) Title   2) Copies available");
            int mode = input.readIntInRange("Choice: ", 1, 2);
            List<Book> books = mode == 1
                    ? service.listBooksByTitle()
                    : service.listBooksByAvailability();
            printBooks(books);
        } catch (SQLException e) {
            System.out.println("Database error while listing books: " + e.getMessage());
        }
    }

    private static void searchBooks() {
        try {
            String keyword = input.readText("Search title / author / category / ISBN: ");
            printBooks(service.searchBooks(keyword));
        } catch (SQLException e) {
            System.out.println("Database error while searching: " + e.getMessage());
        }
    }

    private static void updateBook() {
        try {
            int id = input.readInt("Book id to update: ");
            Book book = service.getBook(id);
            System.out.println("Current: " + book);
            System.out.println("(press Enter to keep the current value)");
            book.setTitle(input.readTextOrDefault("Title [" + book.getTitle() + "]: ",
                    book.getTitle()));
            book.setAuthor(input.readTextOrDefault("Author [" + book.getAuthor() + "]: ",
                    book.getAuthor()));
            book.setCategory(input.readTextOrDefault("Category [" + book.getCategory() + "]: ",
                    book.getCategory()));
            int borrowed = book.getTotalCopies() - book.getAvailableCopies();
            int total = input.readIntInRange("Total copies [" + book.getTotalCopies()
                    + "] (min " + Math.max(borrowed, 1) + "): ", Math.max(borrowed, 1), 1000);
            book.setTotalCopies(total);
            book.setAvailableCopies(total - borrowed);
            service.updateBook(book);
            System.out.println("\nBook updated.");
        } catch (RecordNotFoundException e) {
            System.out.println("\n" + e.getMessage());
        } catch (SQLException e) {
            System.out.println("\nDatabase error while updating: " + e.getMessage());
        }
    }

    private static void deleteBook() {
        try {
            int id = input.readInt("Book id to delete: ");
            Book book = service.getBook(id);
            if (input.confirm("Delete '" + book.getTitle() + "'?")) {
                service.deleteBook(id);
                System.out.println("Book deleted.");
            } else {
                System.out.println("Cancelled.");
            }
        } catch (RecordNotFoundException | BookUnavailableException e) {
            System.out.println(e.getMessage());
        } catch (SQLException e) {
            System.out.println("Database error while deleting: " + e.getMessage());
        }
    }

    private static void printBooks(List<Book> books) {
        if (books.isEmpty()) {
            System.out.println("No books found.");
            return;
        }
        System.out.printf("%-6s %-32s %-20s %-15s %-12s %s%n",
                "ID", "TITLE", "AUTHOR", "ISBN", "CATEGORY", "AVAIL/TOTAL");
        System.out.println("-".repeat(100));
        books.forEach(System.out::println);
        System.out.println("Total: " + books.size() + " title(s).");
    }

    /* ---------------- members ---------------- */

    private static void registerMember() {
        try {
            String name = input.readText("Name: ");
            String email = input.readText("Email: ");
            String phone = input.readText("Phone: ");
            System.out.println("Membership: 1) STANDARD (3 books)  2) PREMIUM (10 books)");
            int type = input.readIntInRange("Choice: ", 1, 2);
            Member member = new Member(0, name, email, phone,
                    type == 1 ? "STANDARD" : "PREMIUM", LocalDate.now());
            service.registerMember(member);
            System.out.println("\nMember registered. Borrow limit: "
                    + member.getBorrowLimit());
        } catch (DuplicateRecordException e) {
            System.out.println("\nCould not register: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("\nDatabase error while registering: " + e.getMessage());
        }
    }

    private static void listMembers() {
        try {
            printMembers(service.listMembers());
        } catch (SQLException e) {
            System.out.println("Database error while listing members: " + e.getMessage());
        }
    }

    private static void searchMembers() {
        try {
            printMembers(service.searchMembers(input.readText("Search name / email: ")));
        } catch (SQLException e) {
            System.out.println("Database error while searching: " + e.getMessage());
        }
    }

    private static void updateMember() {
        try {
            int id = input.readInt("Member id to update: ");
            Member member = service.getMember(id);
            System.out.println("Current: " + member);
            member.setName(input.readTextOrDefault("Name [" + member.getName() + "]: ",
                    member.getName()));
            member.setEmail(input.readTextOrDefault("Email [" + member.getEmail() + "]: ",
                    member.getEmail()));
            member.setPhone(input.readTextOrDefault("Phone [" + member.getPhone() + "]: ",
                    member.getPhone()));
            member.setMembershipType(input.readTextOrDefault(
                    "Membership STANDARD/PREMIUM [" + member.getMembershipType() + "]: ",
                    member.getMembershipType()).toUpperCase());
            service.updateMember(member);
            System.out.println("\nMember updated.");
        } catch (RecordNotFoundException e) {
            System.out.println("\n" + e.getMessage());
        } catch (SQLException e) {
            System.out.println("\nDatabase error while updating: " + e.getMessage());
        }
    }

    private static void deleteMember() {
        try {
            int id = input.readInt("Member id to delete: ");
            Member member = service.getMember(id);
            if (input.confirm("Delete member '" + member.getName() + "'?")) {
                service.deleteMember(id);
                System.out.println("Member deleted.");
            } else {
                System.out.println("Cancelled.");
            }
        } catch (RecordNotFoundException | BookUnavailableException e) {
            System.out.println(e.getMessage());
        } catch (SQLException e) {
            System.out.println("Database error while deleting: " + e.getMessage());
        }
    }

    private static void printMembers(List<Member> members) {
        if (members.isEmpty()) {
            System.out.println("No members found.");
            return;
        }
        System.out.printf("%-6s %-22s %-26s %-14s %-8s %s%n",
                "ID", "NAME", "EMAIL", "PHONE", "TYPE", "JOINED");
        System.out.println("-".repeat(95));
        members.forEach(System.out::println);
        System.out.println("Total: " + members.size() + " member(s).");
    }

    /* ---------------- circulation ---------------- */

    private static void issueBook() {
        try {
            int bookId = input.readInt("Book id: ");
            int memberId = input.readInt("Member id: ");
            Loan loan = service.issueBook(bookId, memberId);
            System.out.printf("%nIssued '%s' to %s. Due on %s (%d days).%n",
                    loan.getBookTitle(), loan.getMemberName(), loan.getDueDate(),
                    LibraryService.LOAN_PERIOD_DAYS);
        } catch (RecordNotFoundException | BookUnavailableException e) {
            System.out.println("\nCannot issue: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("\nDatabase error while issuing: " + e.getMessage());
        }
    }

    private static void returnBook() {
        try {
            int bookId = input.readInt("Book id: ");
            int memberId = input.readInt("Member id: ");
            Loan loan = service.returnBook(bookId, memberId);
            System.out.printf("%nReturned '%s' on %s.%n",
                    loan.getBookTitle(), loan.getReturnDate());
            if (loan.getOverdueDays() > 0) {
                System.out.printf("Overdue by %d day(s). Fine due: Rs. %.2f%n",
                        loan.getOverdueDays(), loan.getFine());
            } else {
                System.out.println("Returned on time. No fine.");
            }
        } catch (RecordNotFoundException e) {
            System.out.println("\n" + e.getMessage());
        } catch (SQLException e) {
            System.out.println("\nDatabase error while returning: " + e.getMessage());
        }
    }

    private static void memberHistory() {
        try {
            int memberId = input.readInt("Member id: ");
            Member member = service.getMember(memberId);
            List<Loan> loans = service.borrowingHistory(memberId);
            System.out.println("\nBorrowing history for " + member.getName()
                    + " (" + member.getMembershipType() + ")");
            if (loans.isEmpty()) {
                System.out.println("No borrowing records yet.");
                return;
            }
            loans.forEach(System.out::println);
        } catch (RecordNotFoundException e) {
            System.out.println("\n" + e.getMessage());
        } catch (SQLException e) {
            System.out.println("\nDatabase error: " + e.getMessage());
        }
    }

    /* ---------------- reports ---------------- */

    private static void borrowedAndOverdueReport() {
        try {
            List<Loan> active = service.currentlyBorrowed();
            System.out.println("== CURRENTLY BORROWED (" + active.size() + ") ==");
            if (active.isEmpty()) {
                System.out.println("Nothing is out on loan.");
            } else {
                active.forEach(System.out::println);
            }

            List<Loan> overdue = service.overdueLoans();
            System.out.println("\n== OVERDUE (" + overdue.size() + ") ==");
            if (overdue.isEmpty()) {
                System.out.println("No overdue items. ");
            } else {
                overdue.forEach(System.out::println);
                System.out.printf("Total outstanding fines: Rs. %.2f%n",
                        service.totalOutstandingFines());
            }
        } catch (SQLException e) {
            System.out.println("Database error while building the report: " + e.getMessage());
        }
    }

    private static void statisticsReport() {
        try {
            System.out.println("== COPIES PER CATEGORY (TreeMap, sorted) ==");
            for (Map.Entry<String, Integer> entry : service.booksPerCategory().entrySet()) {
                System.out.printf("  %-20s %d copies%n", entry.getKey(), entry.getValue());
            }

            System.out.println("\n== TITLES PER AUTHOR (HashMap) ==");
            for (Map.Entry<String, Integer> entry : service.titlesPerAuthor().entrySet()) {
                System.out.printf("  %-25s %d title(s)%n", entry.getKey(), entry.getValue());
            }

            Map<String, Integer> borrowed = service.mostBorrowedTitles();
            System.out.println("\n== TIMES BORROWED PER TITLE ==");
            if (borrowed.isEmpty()) {
                System.out.println("  No loans recorded yet.");
            } else {
                borrowed.entrySet().stream()
                        .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                        .forEach(e -> System.out.printf("  %-32s %d time(s)%n",
                                e.getKey(), e.getValue()));
            }
        } catch (SQLException e) {
            System.out.println("Database error while building statistics: " + e.getMessage());
        }
    }
}
