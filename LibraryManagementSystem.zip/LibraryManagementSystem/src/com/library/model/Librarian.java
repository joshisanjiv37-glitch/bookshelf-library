package com.library.model;

/**
 * Second subtype of Person. Proves the class hierarchy is real:
 * a Librarian has a staff code and a far larger borrow limit.
 */
public class Librarian extends Person {

    private String staffCode;

    public Librarian(int id, String name, String email, String phone, String staffCode) {
        super(id, name, email, phone);
        this.staffCode = staffCode;
    }

    public String getStaffCode() {
        return staffCode;
    }

    public void setStaffCode(String staffCode) {
        this.staffCode = staffCode;
    }

    @Override
    public String getRole() {
        return "LIBRARIAN";
    }

    @Override
    public int getBorrowLimit() {
        return 20;
    }
}
