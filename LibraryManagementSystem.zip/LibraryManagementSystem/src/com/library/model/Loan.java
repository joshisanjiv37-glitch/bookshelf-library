package com.library.model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/** One borrowing record: which member took which book, and when it is due. */
public class Loan {

    public static final double FINE_PER_DAY = 5.0;

    private int id;
    private int bookId;
    private int memberId;
    private String bookTitle;   // filled by JOIN queries for reports
    private String memberName;
    private LocalDate issueDate;
    private LocalDate dueDate;
    private LocalDate returnDate; // null while still borrowed

    public Loan(int id, int bookId, int memberId, LocalDate issueDate,
                LocalDate dueDate, LocalDate returnDate) {
        this.id = id;
        this.bookId = bookId;
        this.memberId = memberId;
        this.issueDate = issueDate;
        this.dueDate = dueDate;
        this.returnDate = returnDate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public LocalDate getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(LocalDate issueDate) {
        this.issueDate = issueDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public boolean isReturned() {
        return returnDate != null;
    }

    /** Days overdue as of today (0 when on time or already returned). */
    public long getOverdueDays() {
        LocalDate reference = returnDate != null ? returnDate : LocalDate.now();
        long days = ChronoUnit.DAYS.between(dueDate, reference);
        return Math.max(0, days);
    }

    /** Stretch goal: fine calculation for overdue returns. */
    public double getFine() {
        return getOverdueDays() * FINE_PER_DAY;
    }

    @Override
    public String toString() {
        String status = isReturned() ? "returned " + returnDate : "BORROWED";
        return String.format("#%-4d %-30s %-18s issued %s due %s  %-18s overdue:%dd fine:Rs.%.2f",
                id, bookTitle == null ? "book " + bookId : bookTitle,
                memberName == null ? "member " + memberId : memberName,
                issueDate, dueDate, status, getOverdueDays(), getFine());
    }
}
