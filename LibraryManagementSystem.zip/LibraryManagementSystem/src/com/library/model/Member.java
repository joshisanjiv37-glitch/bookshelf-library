package com.library.model;

import java.time.LocalDate;

/** A registered library member who can borrow books. */
public class Member extends Person {

    private String membershipType; // STANDARD or PREMIUM
    private LocalDate joinDate;

    public Member(int id, String name, String email, String phone,
                  String membershipType, LocalDate joinDate) {
        super(id, name, email, phone);
        this.membershipType = membershipType;
        this.joinDate = joinDate;
    }

    /** Overloaded constructor (method/constructor overloading example). */
    public Member(String name, String email, String phone) {
        this(0, name, email, phone, "STANDARD", LocalDate.now());
    }

    public String getMembershipType() {
        return membershipType;
    }

    public void setMembershipType(String membershipType) {
        this.membershipType = membershipType;
    }

    public LocalDate getJoinDate() {
        return joinDate;
    }

    public void setJoinDate(LocalDate joinDate) {
        this.joinDate = joinDate;
    }

    @Override
    public String getRole() {
        return "MEMBER";
    }

    @Override
    public int getBorrowLimit() {
        return "PREMIUM".equalsIgnoreCase(membershipType) ? 10 : 3;
    }

    @Override
    public String toString() {
        return String.format("#%-4d %-22s %-26s %-14s %-8s joined %s",
                getId(), getName(), getEmail(), getPhone(), membershipType, joinDate);
    }
}
