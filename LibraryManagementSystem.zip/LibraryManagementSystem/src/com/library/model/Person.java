package com.library.model;

/**
 * Abstract base class for every human actor in the library.
 * Demonstrates abstraction + encapsulation (all fields private).
 */
public abstract class Person {

    private int id;
    private String name;
    private String email;
    private String phone;

    protected Person(int id, String name, String email, String phone) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    /** Each subtype describes its own role - overridden = polymorphism. */
    public abstract String getRole();

    /** Maximum number of books this kind of person may borrow at once. */
    public abstract int getBorrowLimit();

    @Override
    public String toString() {
        return String.format("[%s] #%d %s | %s | %s", getRole(), id, name, email, phone);
    }
}
