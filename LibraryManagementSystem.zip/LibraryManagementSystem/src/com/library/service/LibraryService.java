package com.library.service;

import com.library.dao.BookDAO;
import com.library.dao.LoanDAO;
import com.library.dao.MemberDAO;
import com.library.exception.BookUnavailableException;
import com.library.exception.DuplicateRecordException;
import com.library.exception.RecordNotFoundException;
import com.library.model.Book;
import com.library.model.Loan;
import com.library.model.Member;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Business rules of the library. The DAOs talk to the database; this class
 * decides what is allowed and does all in-memory work with Collections.
 */
public class LibraryService {

    public static final int LOAN_PERIOD_DAYS = 14;

    private final BookDAO bookDAO = new BookDAO();
    private final MemberDAO memberDAO = new MemberDAO();
    private final LoanDAO loanDAO = new LoanDAO();

    /* ---------------- books ---------------- */

    public void addBook(Book book) throws SQLException, DuplicateRecordException {
        bookDAO.insert(book);
    }

    /** Returns all books sorted by title using Comparable. */
    public List<Book> listBooksByTitle() throws SQLException {
        List<Book> books = new ArrayList<>(bookDAO.findAll());
        books.sort(Comparator.naturalOrder());
        return books;
    }

    /** Sorting with an explicit Comparator: most copies available first. */
    public List<Book> listBooksByAvailability() throws SQLException {
        List<Book> books = new ArrayList<>(bookDAO.findAll());
        books.sort(Comparator.comparingInt(Book::getAvailableCopies).reversed()
                .thenComparing(Book::getTitle, String.CASE_INSENSITIVE_ORDER));
        return books;
    }

    public List<Book> searchBooks(String keyword) throws SQLException {
        return bookDAO.search(keyword);
    }

    public Book getBook(int id) throws SQLException, RecordNotFoundException {
        return bookDAO.findById(id);
    }

    public void updateBook(Book book) throws SQLException, RecordNotFoundException {
        bookDAO.update(book);
    }

    public void deleteBook(int id) throws SQLException, RecordNotFoundException,
            BookUnavailableException {
        Book book = bookDAO.findById(id);
        for (Loan loan : loanDAO.findActive()) {
            if (loan.getBookId() == id) {
                throw new BookUnavailableException("'" + book.getTitle()
                        + "' is currently borrowed and cannot be deleted.");
            }
        }
        bookDAO.delete(id);
    }

    /* ---------------- members ---------------- */

    public void registerMember(Member member) throws SQLException, DuplicateRecordException {
        memberDAO.insert(member);
    }

    public List<Member> listMembers() throws SQLException {
        return memberDAO.findAll();
    }

    public List<Member> searchMembers(String keyword) throws SQLException {
        return memberDAO.search(keyword);
    }

    public Member getMember(int id) throws SQLException, RecordNotFoundException {
        return memberDAO.findById(id);
    }

    public void updateMember(Member member) throws SQLException, RecordNotFoundException {
        memberDAO.update(member);
    }

    public void deleteMember(int id) throws SQLException, RecordNotFoundException,
            BookUnavailableException {
        if (loanDAO.countActiveByMember(id) > 0) {
            throw new BookUnavailableException("Member " + id
                    + " still has borrowed books. Collect them first.");
        }
        memberDAO.delete(id);
    }

    /* ---------------- issue / return ---------------- */

    public Loan issueBook(int bookId, int memberId) throws SQLException,
            RecordNotFoundException, BookUnavailableException {
        Book book = bookDAO.findById(bookId);
        Member member = memberDAO.findById(memberId);

        if (!book.isAvailable()) {
            throw new BookUnavailableException("'" + book.getTitle()
                    + "' has 0 copies available right now.");
        }
        int active = loanDAO.countActiveByMember(memberId);
        if (active >= member.getBorrowLimit()) {
            throw new BookUnavailableException(member.getName() + " already holds "
                    + active + " books (limit " + member.getBorrowLimit() + ").");
        }

        LocalDate today = LocalDate.now();
        Loan loan = new Loan(0, bookId, memberId, today,
                today.plusDays(LOAN_PERIOD_DAYS), null);
        loanDAO.insert(loan);
        bookDAO.changeAvailableCopies(bookId, -1);
        loan.setBookTitle(book.getTitle());
        loan.setMemberName(member.getName());
        return loan;
    }

    public Loan returnBook(int bookId, int memberId)
            throws SQLException, RecordNotFoundException {
        Loan loan = loanDAO.findActiveLoan(bookId, memberId);
        loan.setReturnDate(LocalDate.now());
        loanDAO.markReturned(loan);
        bookDAO.changeAvailableCopies(bookId, 1);
        return loan;
    }

    public List<Loan> borrowingHistory(int memberId)
            throws SQLException, RecordNotFoundException {
        memberDAO.findById(memberId); // validates the member exists
        return loanDAO.findByMember(memberId);
    }

    /* ---------------- reports ---------------- */

    public List<Loan> currentlyBorrowed() throws SQLException {
        return loanDAO.findActive();
    }

    /** Filtering a collection: only the loans that are past their due date. */
    public List<Loan> overdueLoans() throws SQLException {
        List<Loan> overdue = new ArrayList<>();
        for (Loan loan : loanDAO.findActive()) {
            if (loan.getOverdueDays() > 0) {
                overdue.add(loan);
            }
        }
        overdue.sort(Comparator.comparingLong(Loan::getOverdueDays).reversed());
        return overdue;
    }

    public double totalOutstandingFines() throws SQLException {
        double total = 0;
        for (Loan loan : overdueLoans()) {
            total += loan.getFine();
        }
        return total;
    }

    /** TreeMap keeps categories alphabetically sorted in the report. */
    public Map<String, Integer> booksPerCategory() throws SQLException {
        Map<String, Integer> counts = new TreeMap<>();
        for (Book book : bookDAO.findAll()) {
            counts.merge(book.getCategory(), book.getTotalCopies(), Integer::sum);
        }
        return counts;
    }

    /** HashMap for fast author -> number of titles statistics. */
    public Map<String, Integer> titlesPerAuthor() throws SQLException {
        Map<String, Integer> counts = new HashMap<>();
        for (Book book : bookDAO.findAll()) {
            counts.merge(book.getAuthor(), 1, Integer::sum);
        }
        return counts;
    }

    /** Uses the id -> Book HashMap index to count loans per book title. */
    public Map<String, Integer> mostBorrowedTitles() throws SQLException {
        Map<Integer, Book> index = bookDAO.findAllAsMap();
        Map<String, Integer> counts = new HashMap<>();
        for (Loan loan : loanDAO.findAll()) {
            Book book = index.get(loan.getBookId());
            String title = book == null ? "deleted book" : book.getTitle();
            counts.merge(title, 1, Integer::sum);
        }
        return counts;
    }
}
