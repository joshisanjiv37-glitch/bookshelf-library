package com.library.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Loads DB settings from config/db.properties (git-ignored) or, if that file is
 * missing, from environment variables DB_URL / DB_USER / DB_PASSWORD.
 * Credentials are never hard-coded in source.
 */
public final class ConfigLoader {

    private static final String CONFIG_PATH = "config/db.properties";
    private static Properties props;

    private ConfigLoader() {
    }

    private static Properties load() {
        if (props != null) {
            return props;
        }
        props = new Properties();
        try (InputStream in = new FileInputStream(CONFIG_PATH)) {
            props.load(in);
        } catch (IOException e) {
            System.out.println("Note: " + CONFIG_PATH
                    + " not found, falling back to environment variables.");
        }
        return props;
    }

    public static String get(String key, String envVar, String defaultValue) {
        String fromFile = load().getProperty(key);
        if (fromFile != null && !fromFile.isBlank()) {
            return fromFile.trim();
        }
        String fromEnv = System.getenv(envVar);
        if (fromEnv != null && !fromEnv.isBlank()) {
            return fromEnv.trim();
        }
        return defaultValue;
    }
}
