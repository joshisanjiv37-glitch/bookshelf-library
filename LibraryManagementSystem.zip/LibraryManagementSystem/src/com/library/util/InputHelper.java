package com.library.util;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

/** Scanner wrapper that validates every value before returning it. */
public class InputHelper {

    private final Scanner scanner;

    public InputHelper(Scanner scanner) {
        this.scanner = scanner;
    }

    public String readText(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            if (!line.isEmpty()) {
                return line;
            }
            System.out.println("  ! This field cannot be empty. Try again.");
        }
    }

    /** Reads optional text; empty input returns the fallback (used for updates). */
    public String readTextOrDefault(String prompt, String fallback) {
        System.out.print(prompt);
        String line = scanner.nextLine().trim();
        return line.isEmpty() ? fallback : line;
    }

    public int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("  ! '" + line + "' is not a whole number. Try again.");
            }
        }
    }

    public int readIntInRange(String prompt, int min, int max) {
        while (true) {
            int value = readInt(prompt);
            if (value >= min && value <= max) {
                return value;
            }
            System.out.printf("  ! Enter a number between %d and %d.%n", min, max);
        }
    }

    public LocalDate readDate(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                return LocalDate.parse(line);
            } catch (DateTimeParseException e) {
                System.out.println("  ! Use the format YYYY-MM-DD (e.g. 2026-01-31).");
            }
        }
    }

    public boolean confirm(String prompt) {
        System.out.print(prompt + " (y/n): ");
        String line = scanner.nextLine().trim();
        return line.equalsIgnoreCase("y") || line.equalsIgnoreCase("yes");
    }

    public void pause() {
        System.out.print("\nPress Enter to continue...");
        scanner.nextLine();
    }
}
